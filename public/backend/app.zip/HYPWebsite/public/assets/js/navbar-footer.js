$(document).ready(function() {
  $("#header-madsomma").load("header.html"); 
  $("#footer-madsomma").load("footer.html"); 
});